# How to run the project

## set virtual environment
	python3 -m venv venv
	source venv/bin/activate

## install required packages using pip
	pip install -r requirements.txt

## run the flask server
	flask --app main run


